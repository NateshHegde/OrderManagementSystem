package com.oms.DAO;

import java.sql.*;
import java.util.*;

import com.oms.model.Employee;
import com.oms.model.Items;
import com.oms.model.Orders;
//import com.sun.xml.internal.ws.wsdl.writer.document.Types;

public class OrdersDAO {
	public static List<Orders> getOrderedItems(){
		ResultSet rs;
		PreparedStatement ps;
		List <Orders> Orderlist = new ArrayList<Orders>();
		try{
			Connection con = AdminDAO.getConnection();
			 ps = con.prepareStatement("select orders.order_id, items.item_name, supplier.supplier_name, orders.order_date, orders.order_quantity, orders.order_cost, orders.order_status, orders.comments from orders join items on orders.item_id = items.item_id join Supplier on Orders.supplier_id = Supplier.supplier_id order by order_date");
			 rs = ps.executeQuery();
			
			while(rs.next()){
				Orders order = new Orders();
				order.setOrder_id(rs.getInt(1)); // note: we need item id to pass it into show suppliers in PM and PE item selection
				order.setItemOrder_name(rs.getString(2));
				order.setSupplierOrders_name(rs.getString(3));
				order.setOrder_date(rs.getTimestamp(4));
				order.setOrder_quantity(rs.getInt(5));
				order.setOrder_price(rs.getFloat(6));
				order.setOrder_status(rs.getString(7));
				order.setComments(rs.getString(8));
				Orderlist.add(order);
			}
			con.close();
			
		}
		
		catch(Exception e){
			System.out.println(e);
			System.out.println("exception from ordersDAO");
		}
		return Orderlist;
	}
	
	
	
	
	public static List<Orders> getOrderedItemsforManager(){
		ResultSet rs;
		PreparedStatement ps;
		List <Orders> Orderlist = new ArrayList<Orders>();
		try{
			Connection con = AdminDAO.getConnection();
			 ps = con.prepareStatement("select orders.order_id, items.item_name, supplier.supplier_name, orders.order_date, orders.order_quantity, orders.order_cost, orders.order_status, orders.comments from orders join items on orders.item_id = items.item_id join Supplier on Orders.supplier_id = Supplier.supplier_id  where order_status='Approved' or order_status='MANAGER APPROVED' or order_status='PENDING' or order_status='SUPPLIER REJECTED' or order_status='SUPPLIER DISPATCHED' or order_status='QC REJECTED' or order_status='ORDER CONFIRMED'  order by order_date");
			 rs = ps.executeQuery();
			
			while(rs.next()){
				Orders order = new Orders();
				order.setOrder_id(rs.getInt(1)); // note: we need item id to pass it into show suppliers in PM and PE item selection
				order.setItemOrder_name(rs.getString(2));
				order.setSupplierOrders_name(rs.getString(3));
				order.setOrder_date(rs.getTimestamp(4));
				order.setOrder_quantity(rs.getInt(5));
				order.setOrder_price(rs.getFloat(6));
				order.setOrder_status(rs.getString(7));
				order.setComments(rs.getString(8));
				Orderlist.add(order);
			}
			con.close();
			
		}
		
		catch(Exception e){
			System.out.println(e);
			System.out.println("exception from ordersDAO");
		}
		return Orderlist;
	}
	
	public static List<Orders> getPendingOrdersforManager(){
		ResultSet rs;
		PreparedStatement ps;
		List <Orders> Orderlist = new ArrayList<Orders>();
		try{
			Connection con = AdminDAO.getConnection();
			 ps = con.prepareStatement("select orders.order_id, items.item_name, supplier.supplier_name, orders.order_date, orders.order_quantity, orders.order_cost from orders join items on orders.item_id = items.item_id join Supplier on Orders.supplier_id = Supplier.supplier_id  where order_status='pending' or order_status='PENDING' order by order_date");
			 rs = ps.executeQuery();
			
			while(rs.next()){
				Orders order = new Orders();
				order.setOrder_id(rs.getInt(1)); // note: we need item id to pass it into show suppliers in PM and PE item selection
				order.setItemOrder_name(rs.getString(2));
				order.setSupplierOrders_name(rs.getString(3));
				order.setOrder_date(rs.getTimestamp(4));
				order.setOrder_quantity(rs.getInt(5));
				order.setOrder_price(rs.getFloat(6));
				
				Orderlist.add(order);
			}
			con.close();
			
		}
		
		catch(Exception e){
			System.out.println(e);
			System.out.println("exception from ordersDAO");
		}
		return Orderlist;
	}

public static int OrderEmployee(Orders order1, int empid )
{
	int status=0;
	
	try
	{
		Connection  con= AdminDAO.getConnection();
		System.out.println("success");
		
		CallableStatement stmt=con.prepareCall("{call emp_order_status(?,?,?,?,?)}");
		
		stmt.setInt(1,order1.getItemId());
		stmt.setInt(2,order1.getSupplierId());
		stmt.setInt(3,order1.getOrder_quantity());
		stmt.setFloat(4,order1.getOrder_price());
		stmt.setInt(5, empid);
		
		System.out.println(order1.getItemId());
		
		
		stmt.executeUpdate();
		System.out.println("success2");
		
		//PreparedStatement ps=con.prepareStatement("" + "delete from employees where employee_id=?");
		//ps.setLong(1, id);
		//status=ps.executeUpdate();
		System.out.println("Procedure Executed");
		con.close();
	}
	catch (Exception e){
		System.out.println("Unable to update");
		e.printStackTrace();}
	return status;
}


public static int OrderPurchaseManager(Orders order2, int mngid)
{
	int status=0;
	try
	{
		Connection  con= AdminDAO.getConnection();
		CallableStatement stmt=con.prepareCall("{call mgr_order_status(?,?,?,?,?)}");
		stmt.setInt(1,order2.getOrder_id());
		stmt.setInt(2,order2.getSupplierId());
		stmt.setInt(3,order2.getOrder_quantity());
		stmt.setFloat(4,order2.getOrder_price());
		stmt.setInt(5,mngid);
		
		System.out.println("");
		System.out.println(order2.getItemOrder_name());
		stmt.executeUpdate();
		
		System.out.println("Procedure Executed");
		con.close();
	}
	catch (Exception e){
		System.out.println("Unable to update");
		e.printStackTrace();}
	return status;
}	
	
public static int acceptOrderManager(Orders order){
	int status=0;
	try
	{
		Connection con= AdminDAO.getConnection();
		PreparedStatement ps=con.prepareStatement("{call mgr_approve_status(?)}");
		ps.setInt(1,order.getOrder_id());
		

	status=ps.executeUpdate();
	con.close();
	}
	catch(Exception e)
	{
		System.out.println("Error adding Order");
		e.printStackTrace();
		
	}return status;
}	
	
public static int rejectOrderManager(Orders order)
{
	int status=0;
	try
	{
		Connection  con= AdminDAO.getConnection();
		PreparedStatement ps=con.prepareStatement("{call mgr_reject_status(?,?)}");
		System.out.println(order.getOrder_id());
		System.out.println(order.getComments());
		ps.setInt(1,order.getOrder_id());
		ps.setString(2,order.getComments());
		

		status=ps.executeUpdate();
		con.close();
	}
	catch (Exception e){
		e.printStackTrace();}
	return status;
}


public static List<Orders> getPendingOrdersforSuppliers(int supid){
	ResultSet rs;
	PreparedStatement ps;
	List <Orders> Orderlist = new ArrayList<Orders>();
	try{
		Connection con = AdminDAO.getConnection();
		 ps = con.prepareStatement("select orders.order_id, items.item_name, supplier.supplier_name, orders.order_date, orders.order_quantity, orders.order_cost from orders join items on orders.item_id = items.item_id join Supplier on Orders.supplier_id = Supplier.supplier_id  where order_status='pending' or order_status='MANAGER APPROVED' and supplier.supplier_id=? order by order_date");
		 ps.setInt(1,supid);
		 
		 rs = ps.executeQuery();
		
		while(rs.next()){
			Orders order = new Orders();
			order.setOrder_id(rs.getInt(1)); // note: we need item id to pass it into show suppliers in PM and PE item selection
			order.setItemOrder_name(rs.getString(2));
			order.setSupplierOrders_name(rs.getString(3));
			order.setOrder_date(rs.getTimestamp(4));
			order.setOrder_quantity(rs.getInt(5));
			order.setOrder_price(rs.getFloat(6));
			
			Orderlist.add(order);
		}
		con.close();
		
	}
	
	catch(Exception e){
		System.out.println(e);
		System.out.println("exception from ordersDAO");
	}
	return Orderlist;
}


public static int acceptOrderSupplier(Orders order){
	int status=0;
	try
	{
		Connection con= AdminDAO.getConnection();
		PreparedStatement ps=con.prepareStatement("{call supp_approve_status(?)}");
		ps.setInt(1,order.getOrder_id());
		

	status=ps.executeUpdate();
	con.close();
	}
	catch(Exception e)
	{
		System.out.println("Error adding Order");
		e.printStackTrace();
		
	}return status;
}


public static int rejectOrderSupplier(Orders order)
{
	int status=0;
	try
	{
		Connection  con= AdminDAO.getConnection();
		PreparedStatement ps=con.prepareStatement("{call supp_reject_status(?,?)}");
		System.out.println(order.getOrder_id());
		System.out.println(order.getComments());
		ps.setInt(1,order.getOrder_id());
		ps.setString(2,order.getComments());
		

		status=ps.executeUpdate();
		con.close();
	}
	catch (Exception e){
		e.printStackTrace();}
	return status;
}


public static List<Orders> getOrderedItemsforQC(){
	ResultSet rs;
	PreparedStatement ps;
	List <Orders> Orderlist = new ArrayList<Orders>();
	try{
		Connection con = AdminDAO.getConnection();
		 ps = con.prepareStatement("select orders.order_id, items.item_name, supplier.supplier_name, orders.order_date, orders.order_quantity, orders.order_cost, orders.order_status, orders.comments from orders join items on orders.item_id = items.item_id join Supplier on Orders.supplier_id = Supplier.supplier_id  where order_status='SUPPLIER DISPATCHED' order by order_date");
		 rs = ps.executeQuery();
		
		while(rs.next()){
			Orders order = new Orders();
			order.setOrder_id(rs.getInt(1)); // note: we need item id to pass it into show suppliers in PM and PE item selection
			order.setItemOrder_name(rs.getString(2));
			order.setSupplierOrders_name(rs.getString(3));
			order.setOrder_date(rs.getTimestamp(4));
			order.setOrder_quantity(rs.getInt(5));
			order.setOrder_price(rs.getFloat(6));
			order.setOrder_status(rs.getString(7));
			order.setComments(rs.getString(8));
			Orderlist.add(order);
		}
		con.close();
		
	}
	
	catch(Exception e){
		System.out.println(e);
		System.out.println("exception from ordersDAO");
	}
	return Orderlist;
}

public static int acceptOrderQC(Orders order){
	int status=0;
	try
	{
		Connection con= AdminDAO.getConnection();
		PreparedStatement ps=con.prepareStatement("{call qc_approve_status(?)}");
		ps.setInt(1,order.getOrder_id());
		

	status=ps.executeUpdate();
	con.close();
	}
	catch(Exception e)
	{
		System.out.println("Error adding Order");
		e.printStackTrace();
		
	}return status;
}	


public static int rejectOrderQC(Orders order)
{
	int status=0;
	try
	{
		Connection  con= AdminDAO.getConnection();
		PreparedStatement ps=con.prepareStatement("{call qc_reject_status(?,?)}");
		System.out.println(order.getOrder_id());
		System.out.println(order.getComments());
		ps.setInt(1,order.getOrder_id());
		ps.setString(2,order.getComments());
		

		status=ps.executeUpdate();
		con.close();
	}
	catch (Exception e){
		e.printStackTrace();}
	return status;
}

	
}
