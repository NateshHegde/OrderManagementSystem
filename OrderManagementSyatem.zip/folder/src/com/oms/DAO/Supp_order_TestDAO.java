package com.oms.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;

import com.oms.model.SupItems;

public class Supp_order_TestDAO {


	public static String getItemName(String item_name){
		 
	String name = null;
	System.out.println(item_name+" DAO");

		 try {

		  Connection con = AdminDAO.getConnection();
		  PreparedStatement ps = con.prepareStatement("select item_name from items where item_name=? ");
		  ps.setString(1, item_name);
		  
		  ResultSet rs = ps.executeQuery();

		  while (rs.next()) {
		   name = rs.getString(1);

		  }

		 } catch (Exception e) {
		  System.out.println("Error fetching item name : " + e);
		 }
		 if(name==null)
		 {
			 return "different";
		 }
		 else {
			 return name;
		 }
	}
	
	
	
	
	public static int getItemID(String name)
	{
		
		int id = 0;
		System.out.println(id+" DAO");

			 try {

			  Connection con = AdminDAO.getConnection();
			  PreparedStatement ps = con.prepareStatement("select item_id from items where item_name=?");
			  ps.setString(1, name);
			  
			  ResultSet rs = ps.executeQuery();

			  while (rs.next()) {
			   id = rs.getInt(1);

			  }
			   
			  
			  

			 } catch (Exception e) {
			  System.out.println("Error fetching item name : " + e);
			 }
			 System.out.println("DAO id : "+id);
			 return id;


	}



	public static int insertNewItem(String item_name, String item_desc)
	{
		int return_id=0;
	
		System.out.println(item_name+" DAO insert");

			 try {

			  Connection con = AdminDAO.getConnection();
			  System.out.println(item_name+" is being passed to insert new item (different)");
			  PreparedStatement ps = con.prepareStatement(" insert into items values (item_seq.nextval,?,?)");
			  ps.setString(1, item_name);
			  ps.setString(2, item_desc);
			   ps.executeQuery();
			   
			 // con.prepareStatement("commit");
			 //
			 // ps.executeQuery();
			  
			  //get the inserted item id
			  
			   PreparedStatement ps1 =  con.prepareStatement("select item_id from items where item_name=?");
			  ps1.setString(1, item_name);
			  ResultSet rs=ps1.executeQuery();
			  while(rs.next())
			  {
				  return_id = rs.getInt(1);
			  }
				 System.out.println(return_id); 
			 
			 }
			 catch (Exception e) {
			  System.out.println("Error inserting item : " + e);
			 }
			 return return_id;
		
		
		
		
		}
	
	
	
	
	public static void insertIntoSupp_order(int item_id, SupItems sup_items)
	{
	
		
		try {

			  Connection con = AdminDAO.getConnection();
			  PreparedStatement ps = con.prepareStatement(" insert into supp_items values (supp_item.nextval,?,?,?,?)");
			  ps.setInt(1, item_id);
			  ps.setInt(2, sup_items.getSupplier_id());
			  ps.setInt(3, sup_items.getCost());
			  ps.setInt(4, sup_items.getQuantity());
			  
			  
			  ResultSet rs = ps.executeQuery();
			
			  System.out.println("Inserted into suppItems");
			 }
			 catch (Exception e) {
			  System.out.println("Error fetching  : " + e);
			 }
			
		
		
	}
	
	
	
	
	
	
	
	
	
	
	public static void setSuppItems(SupItems sup_items, int item_id)
	{
		 try {

			  Connection con = AdminDAO.getConnection();
			 PreparedStatement ps = con.prepareStatement(" insert into supp_items values (supp_item.nextval,?,?,?,?)");
			 ps.setInt(1, item_id);
			ps.setInt(2, sup_items.getSupplier_id());
			 
			 System.out.println(item_id);
			 System.out.println(sup_items.getSupplier_id());
			//int[] oldValues =  Supp_order_TestDAO.getOldItemDetails(item_id);
			// System.out.println(Arrays.toString(oldValues));
			// System.out.println();
			 ps.setInt(3, sup_items.getCost());
			  ps.setInt(4, sup_items.getQuantity());
			  
			 
			 
			  
			  ResultSet rs = ps.executeQuery();
			
			  System.out.println("Inserted into suppItems");
			 }
			 catch (Exception e) {
			  System.out.println("Error fetching  : " + e);
			 }
			
		
		
	}
	
	
	public static int[] getOldItemDetails(int item_id)
	{
		int[] items = new int[2];
		 try {

			  Connection con = AdminDAO.getConnection();
			  PreparedStatement ps = con.prepareStatement("select item_cost,quantity from supp_items where item_id = ?");
			  ps.setInt(1, item_id);
			  ResultSet rs = ps.executeQuery();
			  while(rs.next())
			  {
				  items[0] = rs.getInt(1);
				  items[1] = rs.getInt(2);
			  }
			  }
		 catch(Exception e)
		 {
			 System.out.println("Couldnt fetch old item details"+e);
		 }
		
		return items;
	}
	
}
