package com.oms.model;

import java.util.*;
import java.sql.Timestamp;


public class Orders {
	
public int order_id;
public String itemOrder_name;
public String supplierOrders_name;
public int order_quantity;
public Timestamp order_date;
public float order_price;
public String comments;
public String order_status;
public int employeeOrders_id;
public int supplierId;
public int itemId;

public int getItemId() {
	return itemId;
}
public void setItemId(int itemId) {
	this.itemId = itemId;
}
public int getSupplierId() {
	return supplierId;
}
public void setSupplierId(int supplierId) {
	this.supplierId = supplierId;
}
public int getOrder_id() {
 return order_id;
}
public void setOrder_id(int order_id) {
 this.order_id = order_id;
}

public String getItemOrder_name() {
	return itemOrder_name;
}
public void setItemOrder_name(String itemOrder_name) {
	this.itemOrder_name = itemOrder_name;
}


public String getSupplierOrders_name() {
	return supplierOrders_name;
}
public void setSupplierOrders_name(String supplierOrders_name) {
	this.supplierOrders_name = supplierOrders_name;
}
public int getOrder_quantity() {
 return order_quantity;
}
public void setOrder_quantity(int order_quantity) {
 this.order_quantity = order_quantity;
}
public Timestamp getOrder_date() {
 return order_date;
}
public void setOrder_date(Timestamp order_date) {
 this.order_date = order_date;
}
public float getOrder_price() {
	return order_price;
}
public void setOrder_price(float order_price) {
	this.order_price = order_price;
}
public String getOrder_status() {
 return order_status;
}
public void setOrder_status(String order_status) {
 this.order_status = order_status;
}
public int getEmployeeOrders_id() {
 return employeeOrders_id;
}
public void setEmployeeOrders_id(int employeeOrders_id) {
 this.employeeOrders_id = employeeOrders_id;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}

 }
