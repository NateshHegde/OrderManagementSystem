package com.oms.model;

public class Items {
public int item_id;
public String item_name;
public String item_description;



public int getItem_id() {
	return item_id;
}
public void setItem_id(int item_id) {
	this.item_id = item_id;
}
public String getItem_name() {
	return item_name;
}
public void setItem_name(String item_name) {
	this.item_name = item_name;
}
public String getItem_description() {
	return item_description;
}
public void setItem_description(String item_description) {
	this.item_description = item_description;
}


}
