package com.oms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oms.DAO.SupplierDAO;
import com.oms.DAO.SupplierListDAO;
import com.oms.model.Supplier;
import com.oms.model.SupplierList;

/**
 * Servlet implementation class SupplierList
 */
@WebServlet("/SupplierListServlet")
public class SupplierListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SupplierListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		
		int itemId = Integer.parseInt(request.getParameter("item_id"));
		System.out.println(itemId);
		
		
		int emp_sid = Integer.parseInt(request.getParameter("employee_id"));
		System.out.println(emp_sid);
		
		String type_of_employee = request.getParameter("type_of_employee");
		
		  
		 // System.out.println("Supplier List item id : "+item_id);
		  
		//  String emp_sid = request.getParameter("emp_id");
		//  int emp_id = Integer.parseInt(emp_sid);
		  
		HttpSession session = request.getSession();
		session.setAttribute("item_id", itemId);
		session.setAttribute("employee_id", emp_sid);
	  
		  
		
		List<SupplierList> list = SupplierListDAO.getSupplierList(itemId);
		
		if(type_of_employee.equals("manager")) {
		 RequestDispatcher rd = request.getRequestDispatcher("viewsuppliers.jsp");
			rd.include(request, response);
		}
		else
		{
			 RequestDispatcher rd = request.getRequestDispatcher("viewsuppliersForEmployee.jsp");
				rd.include(request, response);
		}
		

		  
		
		
		
		
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
