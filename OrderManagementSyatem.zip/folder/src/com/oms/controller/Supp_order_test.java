package com.oms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oms.DAO.Supp_order_TestDAO;
import com.oms.model.Employee;
import com.oms.model.Items;
import com.oms.model.SupItems;

/**
 * Servlet implementation class Supp_order_test
 */
@WebServlet("/Supp_order_test")
public class Supp_order_test extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Supp_order_test() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
		PrintWriter out = response.getWriter();
		//String item_name = request.getParameter("item_name");
		//int item_id = Integer.parseInt(request.getParameter("item_id"));
		//String item_description = request.getParameter("item_desc");
		//int supplier_id = Integer.parseInt(request.getParameter("supplier_id"));
		int id=0;
	//	System.out.println(item_name);
		
		
		int supplier_id = Integer.parseInt(request.getParameter("supplier_id"));
		String item_name = request.getParameter("item_name");
		String item_description = request.getParameter("item_description");
		
		int cost = Integer.parseInt(request.getParameter("item_cost"));
		int quantity = Integer.parseInt(request.getParameter("item_quantity"));
	
		
		String check_name = Supp_order_TestDAO.getItemName(item_name);
		System.out.println(check_name);
		System.out.println(check_name+" back to servlet");
		
		
		
			
		SupItems sup = new SupItems();
		sup.setSupplier_id(supplier_id);
		System.out.println(supplier_id);
		sup.setQuantity(quantity);
		sup.setCost(cost);
	
		
		
		Items items = new Items();
		items.setItem_name(item_name);
		items.setItem_description(item_description);

		

		
		
		
		
		
		
		
		
		
		if(check_name.equals(item_name)) {
			System.out.println("checking if new item is entering this loop");
			id = Supp_order_TestDAO.getItemID(check_name);
			System.out.println("same name");
			System.out.println(id);
			System.out.println("Hello");
			Supp_order_TestDAO.setSuppItems(sup,id);
			out.println("<script type=\"text/javascript\">");  
			 out.println("alert('Added item');");  
			 out.println("</script>");
			 request.getRequestDispatcher("supplier.jsp").include(request, response);
			out.close();
			

		}
		else if(check_name.equals("different"))
		{
			System.out.println("New item function");
			int item_id = Supp_order_TestDAO.insertNewItem(item_name,item_description);
			System.out.println(item_id);
			Supp_order_TestDAO.insertIntoSupp_order(item_id,sup);
			System.out.println("back to servlet after inserting");
			out.println("<script type=\"text/javascript\">");  
			 out.println("alert('Added item');");  
			 out.println("</script>");
			 request.getRequestDispatcher("supplier.jsp").include(request, response);
			out.close();
			
		}
		else {
			System.out.println("final else loop");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
