package com.oms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ManagerItemsDisplay
 */
@WebServlet("/ManagerItemsDisplay")
public class PurchaseManagerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PurchaseManagerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
		PrintWriter out = response.getWriter();
		 RequestDispatcher rd =request.getRequestDispatcher("itemsDisplay.jsp");
		 
		 out.println("<script type=\"text/javascript\">");  
		out.println("alert('Sent for Approval');");  
		 out.println("</script>");
		 request.getRequestDispatcher("managerDashboard.jsp").include(request, response);
		 //create a list<Cutomer> in itemsdisplay.jsp with PMDAO.getEmployees();
		 
		 rd.include(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
