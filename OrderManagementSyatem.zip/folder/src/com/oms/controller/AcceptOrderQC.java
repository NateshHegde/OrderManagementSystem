package com.oms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oms.DAO.OrdersDAO;
import com.oms.model.Orders;


@WebServlet("/AcceptOrderQC")
public class AcceptOrderQC extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public AcceptOrderQC() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		String order_idString = request.getParameter("order_id");
		int order_id = Integer.parseInt(order_idString);	
		
		Orders order = new Orders();
		order.setOrder_id(order_id);
		

		int status = OrdersDAO.acceptOrderQC(order);
		out.println("<script type=\"text/javascript\">");  
		 out.println("alert('Ordered Successfully');");  
		 out.println("</script>");
		 request.getRequestDispatcher("quality.jsp").include(request, response);
		 out.close();
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
