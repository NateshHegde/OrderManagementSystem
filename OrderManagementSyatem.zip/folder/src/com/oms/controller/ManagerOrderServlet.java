package com.oms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oms.DAO.OrdersDAO;
import com.oms.model.Orders;

/**
 * Servlet implementation class ManagerOrderServlet
 */
@WebServlet("/ManagerOrderServlet")
public class ManagerOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ManagerOrderServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
       // String order_idString = request.getParameter("order_id");
        //int order_id = Integer.parseInt(order_idString);
        int mng_id = Integer.parseInt(request.getParameter("emp_id"));
		
		int  item_id= Integer.parseInt(request.getParameter("item_id"));
		int sup_id = Integer.parseInt(request.getParameter("supplier_id"));
		int order_quantity = Integer.parseInt(request.getParameter("item_quantity"));
		
		String itemcost = request.getParameter("item_cost");
		//System.out.println(itemOrder_name+supplierOrders_name+order_quantity+order_costString);
		
		
		
		int order_price = Integer.parseInt(itemcost);
		int totalCost =  (order_quantity * order_price );
		
		String comments = request.getParameter("comments");
		
	System.out.println(mng_id+" "+item_id+" "+order_quantity+" "+totalCost+" "+sup_id);
		

		Orders order = new Orders();
		
		order.setOrder_id(item_id);
		order.setSupplierId(sup_id);
		order.setOrder_quantity(order_quantity);
		order.setOrder_price(totalCost);
		order.setComments(comments);

		
		int status = OrdersDAO.OrderPurchaseManager(order, mng_id);
		out.println("<script type=\"text/javascript\">");  
		 out.println("alert('Order Placed');");  
		 out.println("</script>");
		 request.getRequestDispatcher("managerDashboard.jsp").include(request, response);

		//out.print("<p>Record Saved Successfully</p>");

//		response.sendRedirect("EmployeeDashboard.jsp"); 

	
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);

	}

}
