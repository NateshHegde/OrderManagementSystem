package com.oms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oms.DAO.AdminDAO;
import com.oms.DAO.OrdersDAO;
import com.oms.model.Employee;
import com.oms.model.Orders;


@WebServlet("/EmployeeOrderServlet")
public class EmployeeOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public EmployeeOrderServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
       // String order_idString = request.getParameter("order_id");
        //int order_id = Integer.parseInt(order_idString);
		int emp_id = Integer.parseInt(request.getParameter("emp_id"));
		int item_id= Integer.parseInt(request.getParameter("item_id"));
		
		System.out.println("item id from jsp "+item_id);
		int supplier_id = Integer.parseInt(request.getParameter("supplier_id"));
		int item_quantity = Integer.parseInt(request.getParameter("item_quantity"));
		
		int item_cost = Integer.parseInt(request.getParameter("item_cost"));
		
		int totalCost = (item_quantity*item_cost);
		//System.out.println(itemOrder_name+supplierOrders_name+order_quantity+order_costString);
		String comments = request.getParameter("comments");
		
	
		

		Orders order = new Orders();
		
		order.setItemId(item_id);
		order.setSupplierId(supplier_id);
		order.setOrder_quantity(item_quantity);
		order.setOrder_price(totalCost);
		order.setComments(comments);
		
		int status = OrdersDAO.OrderEmployee(order,emp_id);

		out.println("<script type=\"text/javascript\">");  
		 out.println("alert('Sent for Approval');");  
		 out.println("</script>");
		 request.getRequestDispatcher("empDashboard.jsp").include(request, response);

//		response.sendRedirect("EmployeeDashboard.jsp"); 
	}

	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);

	}

}
